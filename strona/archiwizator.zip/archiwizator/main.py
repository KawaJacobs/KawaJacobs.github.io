import os,sys,random, pyautogui
import tkinter as tk
from tkinter import filedialog, Text

paths = []

def select_folder():
    path = filedialog.askdirectory(initialdir="/", title="Select folder")
    with open("path.txt", "a") as path_file:
        path_file = path_file.write(f"{path}\n")
        tk.Label(frame, text=path).pack()

def archive():
    with open(f"{os.path.split(os.path.abspath(__file__))[0]}\path.txt", "r") as file:
        file_contents = file.read()
        pyautogui.alert(f"Success!\n{file_contents}", title="Archiwizer")
        

# def create_script():
#     file_name = str(random.randint(1,1000))
#     with open("names.arhvconf","r") as file:
#         file = file.readlines()
#         while file_name in file:
#             file_name = f"{random.randint(1,1000)}\n"
#     with open("names.arhvconf", "a") as file:
#         file.write(file_name)
#     startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
#     file_path = os.path.join(startup_folder, str(file_name))
#     with open(f"archive.bat", 'w') as f:
#         f.write(f"python {__file__} ARCHV_MODE")

def create_script():
    startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
    file_path = os.path.join(startup_folder, "archive.bat")
    with open(file_path, 'w') as f:
        f.write(f"python {__file__} ARCHV_MODE")

if len(sys.argv) > 1:
    archive()
    sys.exit(0)

root = tk.Tk()

canvas = tk.Canvas(root, height=200, width=200, bg="#bdbdbd")
canvas.pack()

frame = tk.Frame(canvas, bg="#bdbdbd", width=100, height=100, border=50)
frame.pack()

select_folder = tk.Button(frame, text="select folder", command=select_folder)
select_folder.pack()

create_scr = tk.Button(frame,text="update list of folders", command=create_script)
create_scr.pack()

root.mainloop()